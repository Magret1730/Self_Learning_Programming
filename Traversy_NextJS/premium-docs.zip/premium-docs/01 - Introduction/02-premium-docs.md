# Premium Docs

So if you purchased this course from traversymedia.com, you get full access to the premium docs, which is basically the entire course in written format. The markdown files include all of the code samples and added explanations for every single video. You can download them on this page. Just click the download button and you'll all of the markdown files.

I suggest opening VS Code or another Markdown reader and just keep it open to the side while you take the course and you can then reference whichever section and lesson you need.